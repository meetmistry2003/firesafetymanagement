<?php
// Connect to MySQL database
$conn = mysqli_connect("localhost", "root", "", "myoffice");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch data from MySQL database
$sql = "SELECT * FROM cust_date";
$result = mysqli_query($conn, $sql);

// Load PDF library
require('fpdf.php');

// Create PDF object
$pdf = new FPDF();
$pdf->AddPage();

// Set font and colors
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetTextColor(0, 0, 0);

// Add header row
$pdf->Cell(50, 10, 'cname', 1, 0, 'C');
$pdf->Cell(50, 10, 'estimate', 1, 0, 'C');
$pdf->Cell(40, 10, 'company_name', 1, 1, 'C');

// Add data rows
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(50, 10, $row['cname'], 1, 0, 'C');
    $pdf->Cell(50, 10, $row['estimate'], 1, 0, 'C');
    $pdf->Cell(40, 10, $row['company_name'], 1, 1, 'C');
}

// Output PDF
$pdf->Output();
?>
